import React from 'react';
import logo from './logo.svg';
// import './App.css';
import RoutePage from './route/routePage';
import SecondComponent from './mobile/Second-Component';
import SecondComponentMobileView from './model/secondComponentMobile';

function App() {
  return (
    <div className="App">
        {/* <RoutePage/> */}
        {/* <SecondComponent /> */}
        <SecondComponentMobileView/>
    </div>
  );
}

export default App;
