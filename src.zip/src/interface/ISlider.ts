export interface ISlider{
    id:number;
    name:string;
  

}