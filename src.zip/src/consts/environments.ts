export const BASE_URL ="https://mocki.io/v1/9b7affb4-c3b6-40f0-b5fb-57083dd93551";
export const GET_SLIDER_DETAILS ="/sliderDetails";